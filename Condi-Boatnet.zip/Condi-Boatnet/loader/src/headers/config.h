#pragma once

#define HTTP_SERVER "170.187.197.25"
#define HTTP_PORT 80

#define TFTP_SERVER "170.187.197.25
